# User Stories Backlog

- As a player, I clean up items while avoiding cows.
- As a team, we revive downed teammates.
- As a player, I rescue teammates from the farmer.
