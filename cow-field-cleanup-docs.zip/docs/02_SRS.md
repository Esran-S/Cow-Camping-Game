# Software Requirements Specification

Refer to full SRS discussed in planning:
- Multiplayer 1–6 (P2P first)
- Procedural levels
- Cow + Farmer AI
- Downed & rescue system
- Inventory, bag weight, stamina
- Camp phase between levels
- Voice chat with moderation
- Highlight replay system
