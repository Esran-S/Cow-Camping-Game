# Technical Architecture

- Unreal Engine
- Host authoritative P2P
- Behavior Trees for AI
- Seeded procedural generation
