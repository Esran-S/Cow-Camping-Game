# Non-Functional Requirements

- Performance stability
- Anti-griefing
- Accessibility
