# Risks & Assumptions

- Physics desync risk
- Voice moderation risk
