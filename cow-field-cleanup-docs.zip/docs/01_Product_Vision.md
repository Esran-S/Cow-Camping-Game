# Cow Field Cleanup – Product Vision

## Elevator Pitch
Cow Field Cleanup is a chaotic slapstick co-op roguelite for 1–6 players where friends wake up after a party in a procedurally generated cow field and must clean up their camping mess before escaping.

## Core Pillars
- Slapstick physics comedy
- Audio-driven stealth
- Procedural replayability
- Streamer-friendly design
