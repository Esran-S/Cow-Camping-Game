# MoSCoW Scope

## Must
- Core gameplay loop
- Multiplayer
- Procedural fields
- Cow AI & Farmer AI

## Should
- Weather
- Biome variety

## Could
- Dedicated servers
- Crossplay

## Won't (v0.1)
- Full replay editor
