# Naming Conventions

- BP_PlayerCharacter
- BP_Cow_Bull
