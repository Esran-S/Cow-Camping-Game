# Git Standards

- main / develop / feature/*
- Conventional commits
