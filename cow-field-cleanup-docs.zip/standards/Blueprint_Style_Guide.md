# Blueprint Style Guide

- Clean graphs
- Comment everything
