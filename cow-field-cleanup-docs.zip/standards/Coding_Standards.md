# Coding Standards

- Unreal C++ + Blueprint hybrid
- No Tick abuse
- Data-driven design
